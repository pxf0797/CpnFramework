/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : CpnCcpCfg.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2020/07/07 15:00:08
* Description  : 
* Others       : 
* History      : 200707 pxf ���ν���
***************************************************************************/

#ifndef CPNCCPCFG_H_
#define CPNCCPCFG_H_

/*ͷ�ļ�����*/

/*���� : CpnCcpCfg()
* ���� : ��
* ��� : ��
* ���� : ��
***********************************************/
void CpnCcpCfg(void);

#endif /*CPNCCPCFG_H_*/

/**************************** Copyright(C) pxf ****************************/
