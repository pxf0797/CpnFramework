/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : CpnCcpSigs.c
* Author       : pxf
* Version      : v1.0
* Created on   : 2020/07/07 15:00:08
* Description  : CpnCcp����źŶ���Դ�ļ�
* Others       :
* History      : 200707 pxf ���ν���
***************************************************************************/

/*ͷ�ļ�����*/
#include "./CpnCcp.h"
#include "./CpnCcpSigs.h"
#include "../../CpnRte/RteSigs/RteSigs.h"

/***********************************************************
* CpnCcp�ඨ��
***********************************************************/
/*CpnCcp��
***********************************************/
CpnCcp clCpnCcp;


/***********************************************************
* serv trig �źŽӿڶ���
* ��̳еĽӿھ��Ǵ����źŽӿڣ��ڽӿں�����ʹ�ô����źŽ��д���
***********************************************************/
/*�����ʼ������
***********************************************/
void serv_CpnCcp_init(void){
    CNNP(CpnCcp,&clCpnCcp);
    if(OPRS(clCpnCcp) != NULL){
        addTaskParam taskParam;
        taskParam.level = level1;
        taskParam.t = taskCpnCcp;
        taskParam.prdTick = 11*MS_T;
        taskParam.startTick = 5*MS_T;
        clRteSynSigs.trig(clRteSynSigs.self, sig_trig_CpnCcp_addTask, (uint8*)&taskParam);
    }
}

/*����
***********************************************/
void serv_CpnCcp_getData(void){}
/*����
***********************************************/
void serv_CpnCcp_setData(void){}

/*�ӿڴ���
***********************************************/
//void trig_CpnCcp_inf_infFunc(void){}



/***********************************************************
* �����������
***********************************************************/
/*����������
***********************************************/
void taskCpnCcp(void){
    clCpnCcp.run(clCpnCcp.self);
}

/**************************** Copyright(C) pxf ****************************/
