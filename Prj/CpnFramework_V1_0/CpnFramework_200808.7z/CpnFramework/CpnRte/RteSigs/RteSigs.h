/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : RteSigs.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2019/12/29 15:41:45
* Description  :
* Others       :
* History      : 191229 pxf ���ν���
***************************************************************************/

#ifndef RTESIGS_H_
#define RTESIGS_H_

/*�����źŽ���ƥ��*/
#include "./RteAsynSigs.h"
#include "./RteSynSigs.h"

#endif /*RTESIGS_H_*/

/**************************** Copyright(C) pxf ****************************/
