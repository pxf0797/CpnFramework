/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : FuncLib.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2020/07/07 11:11:05
* Description  : 
* Others       : 
* History      : 200707 pxf ���ν���
***************************************************************************/

#ifndef FUNCLIB_H_
#define FUNCLIB_H_

/*ͷ�ļ�����*/
#include "../standType/standType.h"
#include "../oopc/oopc.h"
#include "./Fifo/Fifo.h"
#include "./Func/Func.h"


#endif /*FUNCLIB_H_*/

/**************************** Copyright(C) pxf ****************************/
