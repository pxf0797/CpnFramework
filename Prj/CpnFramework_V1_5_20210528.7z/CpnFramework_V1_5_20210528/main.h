/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : main.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2019/12/28 23:30:09
* Description  :
* Others       :
* History      : 191228 pxf ���ν���
***************************************************************************/

#ifndef MAIN_H_
#define MAIN_H_

/*ͷ�ļ�����*/
#include "./CpnRte/RteSigs/RteSigs.h"

/*���� : main()
* ���� : ��
* ��� : ��
* ���� : ��
***********************************************/
int main(void);

#endif /*MAIN_H_*/

/**************************** Copyright(C) pxf ****************************/
