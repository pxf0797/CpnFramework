/**************************************************************************
 * Copyright    : Copyright(C), 2021, pxf, person.
 * File name    : SkipList.c
 * Author       : pxf
 * Version      : v1.0
 * Created on   : 2021/10/10 21:46:26
 * Description  : SkipList class functions definition source file.
 * Others       : 
 * History      : 20211010 pxf Initially established.
 **************************************************************************/

/* Include head files. */
#include "SkipList.h"

/***********************************************************
 * Data type definition.
 **********************************************************/
/* Data definition.
 **********************************************/
/* TODO */

/***********************************************************
 * SkipList class definition.
 **********************************************************/
/* Function : SkipList_find(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
htsSkipList SkipList_find(hSkipList cthis, void *block){
    htsSkipList skipListRet = OOPC_NULL;
    htsSkipList skipList = OOPC_NULL;
    slType findOrder = 0u;
    slType CurrOrder = 0u;
    slType low = 0u, mid = 0u, high = 0u;
    do{
        /* dispose abnormal. */
        if(!(cthis->arrayCnt&&cthis->blockCnt)){
            break;
        }

        findOrder = cthis->blockOrder.blockOrder(block);
        /* bin search id index */
        low = 0u;
        high = (cthis->arrayCnt-1u);
        while(low <= high){
            /* Odd number, no matter even or odd, just have a value. */
            mid = ((low+high)>>1u);
            CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[mid]->block);

            if(findOrder < CurrOrder){
                if(mid == 0u){
                    break;
                }
                /* Is mid-1, because mid has been compared. */
                high = (mid-1u);

                CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[high]->block);
                if(findOrder >= CurrOrder){
                    /* find the region, judge the block. */
                    if(findOrder == CurrOrder){
                        skipListRet = cthis->slArray[high];
                    }else{
                        skipList = cthis->slArray[high];
                        while(skipList != cthis->slArray[mid]){
                            skipList = skipList->next;
                            CurrOrder = cthis->blockOrder.blockOrder(skipList->block);
                            if(findOrder == CurrOrder){
                                skipListRet = skipList;
                                break;
                            }
                        }
                    }
                    break;
                }
            }else if(findOrder > CurrOrder){
                /* Is mid+1, because mid has been compared. */
                low = (mid+1u);

                CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[low]->block);
                if(findOrder <= CurrOrder){
                    /* find the region, judge the block. */
                    if(findOrder == CurrOrder){
                        skipListRet = cthis->slArray[low];
                    }else{
                        skipList = cthis->slArray[mid];
                        while(skipList != cthis->slArray[low]){
                            skipList = skipList->next;
                            CurrOrder = cthis->blockOrder.blockOrder(skipList->block);
                            if(findOrder == CurrOrder){
                                skipListRet = skipList;
                                break;
                            }
                        }
                    }
                    break;
                }
            }else{
                skipListRet = cthis->slArray[mid].block;
                break;
            }
        }
    }while(0);
    return skipListRet;
}

/* Function : SkipList_findSmaller(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
htsSkipList SkipList_findSmaller(hSkipList cthis, void *block){
    htsSkipList skipListRet = OOPC_NULL;
    htsSkipList skipList = OOPC_NULL;
    slType findOrder = 0u;
    slType CurrOrder = 0u;
    slType low = 0u, mid = 0u, high = 0u;

    do{
        /* dispose abnormal. */
        if(!(cthis->arrayCnt&&cthis->blockCnt)){
            break;
        }

        findOrder = cthis->blockOrder.blockOrder(block);
        /* bin search id index */
        low = 0u;
        high = (cthis->arrayCnt-1u);
        while(low <= high){
            /* Odd number, no matter even or odd, just have a value. */
            mid = ((low+high)>>1u);
            CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[mid]->block);

            if(findOrder < CurrOrder){
                if(mid == 0u){
                    break;
                }
                /* Is mid-1, because mid has been compared. */
                high = (mid-1u);

                CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[high]->block);
                if(findOrder >= CurrOrder){
                    /* find the region, judge the block. */
                    if(findOrder == CurrOrder){
                        skipListRet = cthis->slArray[high];
                    }else{
                        skipList = cthis->slArray[high];
                        while(skipList != cthis->slArray[mid]){
                            skipList = skipList->next;
                            CurrOrder = cthis->blockOrder.blockOrder(skipList->block);
                            if(findOrder == CurrOrder){
                                skipListRet = skipList;
                                break;
                            }
                        }
                    }
                    break;
                }
            }else if(findOrder > CurrOrder){
                /* Is mid+1, because mid has been compared. */
                low = (mid+1u);

                CurrOrder = cthis->blockOrder.blockOrder(cthis->slArray[low]->block);
                if(findOrder <= CurrOrder){
                    /* find the region, judge the block. */
                    if(findOrder == CurrOrder){
                        skipListRet = cthis->slArray[low];
                    }else{
                        skipList = cthis->slArray[mid];
                        while(skipList != cthis->slArray[low]){
                            skipList = skipList->next;
                            CurrOrder = cthis->blockOrder.blockOrder(skipList->block);
                            if(findOrder == CurrOrder){
                                skipListRet = skipList;
                                break;
                            }
                        }
                    }
                    break;
                }
            }else{
                skipListRet = cthis->slArray[mid].block;
                break;
            }
        }
    }while(0);
    return skipListRet;
}

/* Function : SkipList_add(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
void SkipList_add(hSkipList cthis, void *block){
    /* TODO */
}

/* Function : SkipList_del(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
void SkipList_del(hSkipList cthis){
    /* TODO */
}

/* Function : SkipList_addDynUpdate(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
void SkipList_addDynUpdate(hSkipList cthis){
    /* TODO */
}

/* Function : SkipList_delDynUpdate(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   :  
 * Others   : SkipList class function.
 **********************************************/
void SkipList_delDynUpdate(hSkipList cthis){
    /* TODO */
}

/* Function : hSkipList SkipList_init(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   : hSkipList - cthis/OOPC_NULL
 * Others   : SkipList class initial function.
 **********************************************/
hSkipList SkipList_init(hSkipList cthis){
    hSkipList retRes = cthis;

    do{
        /* specific failure detected */
        /*
        if(condition){
            break;
        }
        */
        /* Configure functions. */
        //cthis->find = SkipList_find;
        /* TODO */

        /* Configure parameters. */
        /* TODO */
    }while(0);
    return retRes;
}

/* Function : hSkipList SkipList_ctor(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   : hSkipList - cthis/OOPC_NULL
 * Others   : SkipList class constructor.
 **********************************************/
CC(SkipList){
    hSkipList retRes = cthis;

    do{
        /* specific failure detected */
        /*
        if(condition){
            break;
        }
        */
        cthis->init = SkipList_init;
        cthis->find = SkipList_find;
        cthis->add = SkipList_add;
        cthis->del = SkipList_del;
        cthis->addDynUpdate = SkipList_addDynUpdate;
        cthis->delDynUpdate = SkipList_delDynUpdate;
        /* TODO */

        /* Configure parameters. */
        /* TODO */
    }while(0);
    return retRes;
}

/* Function : hSkipList SkipList_dtor(hSkipList cthis)
 * Input    : cthis - SkipList class pointer
 * Output   : OOPC_RETURN_DATATYPE - OOPC_TRUE/OOPC_FALSE
 * Others   : SkipList class destructor.
 **********************************************/
CD(SkipList){
    return OOPC_TRUE;
}

/**************************** Copyright(C) pxf ****************************/
