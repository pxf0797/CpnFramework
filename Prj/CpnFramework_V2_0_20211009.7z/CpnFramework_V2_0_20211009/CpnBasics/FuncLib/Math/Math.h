/**************************************************************************
 * Copyright    : Copyright(C), 2021, pxf, person.
 * File name    : Math.h
 * Author       : pxf
 * Version      : v1.0
 * Created on   : 2021/04/10 15:33:52
 * Description  :
 * Others       :
 * History      : 20210410 pxf Initially established.
 **************************************************************************/

#ifndef MATH_H_
#define MATH_H_

/* Include head files. */
#include "./SineTable.h"


#endif /*MATH_H_*/

/**************************** Copyright(C) pxf ****************************/
